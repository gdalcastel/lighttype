"""LightType API."""
